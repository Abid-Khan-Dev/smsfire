# Release notes

## 0.1.0 (unreleased)

First version. Backend-first SMS client for SMS Gateway for Android (unofficial).

**Included:** `createSms` (send, bulk, templates, scheduling fields, retries, idempotency keys, logs, sync, watch, cancel, webhooks, doctor), `estimate`, `normalizePhone`, `renderTemplate`, `verifyWebhook`, `memoryStore`, `smsfire/mongoose`, `smsfire/express`, `smsfire/fetch`, `smsfire/client`, `npx smsfire doctor`.

**Verified (automated):** 88 tests against a scriptable fake gateway (202/401/403/404/409/429/502/503/504, timeouts, network errors, invalid JSON, status progression, cancel, webhooks), Express adapter over a real HTTP server, clean ESM and CJS installs from `npm pack`, TypeScript resolution under `nodenext`, main entry ~7 kB min+gzip with no Node-only APIs.

**NOT yet verified (must be done before publishing):**
- Everything in the "To verify" table in `docs/GATEWAY-NOTES.md`: no real phone, Local, Cloud or Private server has been tested yet. Request/response shapes, custom message IDs, 409 behaviour, cancel, scheduling fields and webhook signing are based on documentation only.
- `mongooseStore` against a real MongoDB (the shared store contract tests run for the memory store; set `MONGODB_URI` to run them against Mongo).
- Node 24 and 26 (tested on Node 22 only).

**Decisions that differ from the first plan:** no React entry, no KV store, no `unsafe` browser mode; `smsHandler(sms, options)` returns a `(Request) => Response` handler; `verifyWebhook` is async (Web Crypto); server auth is a single predicate `auth(req)`; the mode is inferred from the URL.
